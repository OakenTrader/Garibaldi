#!/usr/bin/env python

from src.helpers.GUI import *

if __name__ == "__main__":
    a = Main_Menu()