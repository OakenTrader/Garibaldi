# Run your Python script inside the virtual environment
python3 main.py